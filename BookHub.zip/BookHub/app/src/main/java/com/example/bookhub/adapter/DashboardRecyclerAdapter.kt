package com.example.bookhub.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.bookhub.R
import com.example.bookhub.activity.DescriptionActivity
import com.example.bookhub.model.Book
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.recycler_dashboard_single_row.view.*

class DashboardRecyclerAdapter(
    val context: Context,
    val bookInfoList:ArrayList<Book>

) : RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_dashboard_single_row, parent, false)
        return DashboardViewHolder(view)

    }

    override fun getItemCount(): Int {
        return bookInfoList.size
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val text = bookInfoList[position]
        holder.txtBookName.text = text.bookName
        holder.txtBookAuthor.text = text.bookAuthor
        holder.txtRating.text = text.bookRating
        holder.txtPrice.text = text.bookPrice
        //holder.imgIcon.setImageResource(text.bookImage)
        Picasso.get().load(text.bookImage).error(R.drawable.default_book_cover).into(holder.imgIcon);
        holder.llContent.setOnClickListener {
            println("CLICKED")
            val intent= Intent(context,DescriptionActivity::class.java)
            intent.putExtra("book_id",text.bookId)
            context.startActivity(intent)
        }


    }

    class DashboardViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtBookName: TextView = view.findViewById(R.id.txtRecyclerRowItem)
        val txtBookAuthor:TextView=view.findViewById(R.id.txtRecyclerRowAuthor)
        val txtRating:TextView=view.findViewById(R.id.txtRating)
        val txtPrice:TextView=view.findViewById(R.id.txtRecyclerRowPrice)
        val imgIcon:ImageView =view.findViewById(R.id.imgBookIcon)
        val llContent : LinearLayout = view.findViewById(R.id.llContent)
    }
}